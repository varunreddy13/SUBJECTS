/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import pizzas.Sides.Cheese;

/**
 *
 * @author  Sri Vasavi Vipparla
 */
public class OrderDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        
      //1. Declare and initialize a scanner object to read from file "input.txt"
        System.out.println("*****************************************************");
        System.out.println("*********************** Pizza Hut ******************");
        System.out.println("*****************************************************");
        while (scan.hasNext()) {
			//2. Declare and initialize an OrderSummary object and name it as orderSum
			//3. Read date and pass the date to the getOrderDayOfWeek method
			//4. Read pizzas name and convert it to PizzaTypes enum. Note: You can convert to PizzaTypes enum here in the main method or you can create a                                private static method after main method in the same class to convert a string that is read to PizzaTypes enum. Do not use switch or if                              else to convert to enums
			//5. Read size and number of Pizzas per order according to the input given in the input file
			//6. Read Sauce, Sides, Cheese and Drinks and convert them to corresponding enums. 
                             Please follow same rules as provided above for PizzaTypes enums. 
                        //7. Create an Order object with above attributes and name it as order
			
			//8. Add order, an Order object created above to orderSum object which is an orderSummary Class object
			//9. Print the receipt for orders.
        }

    }