import java.util.ArrayList;

public class BookDriver
{
  public static void main(String[] args)
  {
	 ArrayList<Book> mybooks = new ArrayList<Book>();
	 mybooks.add(new Book("Horse Heaven", 17.00));
	 mybooks.add(new Book("Data Warehousing", 75.50));
	 mybooks.add(new Book("The Kite Runner", 25.00));
	 mybooks.add(new Book("The Iliad", 23.75));
	 
	 for(Book b: mybooks)
	 {
		System.out.println(b);
	 }
	 System.out.println();
	 mybooks.set(1, new Book("Web Services", 70.00));
	 	 
	 for(Book b: mybooks)
	 {
		System.out.println(b);
	 }
	 System.out.println();
	 // Find the average price of the books
	 double sum = 0.0;

	 for(Book b : mybooks)
	 {
		sum += b.getPrice();
	 }
	 System.out.println("Average price: " + sum / mybooks.size());
	 System.out.println();
	 
	 // Find the average price of the books greater than $20.00
	 sum = 0.0;
	 int count = 0;

	 for(Book b : mybooks)
	 {
		if(b.getPrice() > 20)
		{
		  sum += b.getPrice();
		  count ++;
		}
	 }
	 System.out.println("Average price of books > 20.00 : " + 
		sum / count);
	 System.out.println();
	 
	 String[] bookTitles = new String[5];
//	 for(int i = 0; i < mybooks.size(); i++)
//	 {
//		bookTitles[i] = mybooks.get(i).getTitle();
//	 }
	 int i = 0;
	 for(Book b : mybooks)
	 {
		bookTitles[i] = b.getTitle();
		i++;
	 }
	 for(String str : bookTitles)
	 {
		System.out.println(str);
	 }
	 System.out.println();
	 mybooks.remove(1);
	 
	 for(Book b: mybooks)
	 {
		System.out.println(b);
	 }
  }
}
