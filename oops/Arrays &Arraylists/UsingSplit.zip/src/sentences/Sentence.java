package sentences;

/**
 * @author 
 */
public class Sentence
{

   private String sentence;

   public Sentence(String sentence)
   {
      this.sentence = sentence;
   }

   public String getFirstWord()
   {
      String[] words = sentence.split(" ");
      return words[0];
   }
   
   public String getLastWord()
   {
      return "";
   }
   
   public int getNumberOfWords()
   {
      return 0;
   }

   @Override
   public String toString()
   {
      return sentence;
   }
}
