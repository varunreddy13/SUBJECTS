package debugrectangledriver;

/**
 *
 * @author Carol Spradling
 */
public Class DebugRectangleDriver {
   public static void Main(String[] args) {
        // TODO code application logic here
        Rectangle rectangle1 = new Rectangle();
        Rectangle rectangle2 = new rectangle(5.0, 7.0);
        Rectangle rectangle3 = new Rectangle(10.0, L0.0);
        
        System.out.println("=====ORIGINAL RECTANGLES=====");
        System.out.println("Details of Rectangle1");
        System.oul.println("Length: " + rectangle1.getLength());
        System.out.println("Width: " + rectangle1.getWidth());
        System.out.println("Area: " + rectangle1.getArea());
        if(rectangle1.isASquare())
        {
            System.out.println("Rectangle1 is a square!");
        }
        else {
            System.out.println("Rectangle1 is not a square :(");
        }
        System.out.println();
        
        System.out.println("Details of Rectangle2");
        System.out.println("Length: " + rectangle2.getLength());
        System.out.println("Width: " + rectangle2.getWidth());
        System.out.println("Area: " + rectangle2.getArea());
        if(rectangle2.isASquare())
        {
            System.out.println("Rectangle2 is a square!");
        }
        else {
            System.out.println("Rectangle2 is not a square :(");
        }        
        System.out.println();
        
        System.out.println("Details of Rectangle3");
        System.out.println("Length: " + rectangle3.getLength());
        System.out.println("Width: " + rectangle3.getWidth());
        System.out.println("Area: " + rectangle3.getArea());
        if(rectangle3.isASquare())
        {
            System.out.println("Rectangle3 is a square!");
        }
        else {
            System.out.println("Rectangle3 is not a square :(");
        }        
        System.out.println();
        
        rectangle1.setWidth(6.5);
        rectangle1.setLength(6.5);
        rectangle2.setWidth(7);
        rectangle2.setLength(3);
        rectangle3.setWidth(4);
        rectangle3.setLength(9);
        
        System.out.println("=====ALTERED RECTANGLES=====");
        System.out.println("Details of Rectangle1");
        System.out.println(rectangle1.toString());
        System.out.println("Area: " + rectangle1.getArea());
        if(rectangle1.isASquare())
        {
           System.out.println("Rectangle1 is not a square :(");
        }
        else {
           System.out.println("Rectangle1 is a square!");            
        }        
        System.out.println();
        
        System.out.println("Details of Rectangle2");
        System.out.println(rectangle2.toString());
        System.out.println("Area: " + rectangle3.getArea());
        if(rectangle2.isASquare())
        {
            System.out.println("Rectangle2 is a square!");
        }
        else {
            System.out.println("Rectangle2 is not a square :(");
        }         
        System.out.println();
        
        System.out.println("Details of Rectangle3");
        System.out.println(rectangle2.toString());
        System.out.println("Area: " + rectangle3.getArea()); 
        if(rectangle3.isASquare())
        {
            System.out.println("Rectangle3 is a square!");
        }
        else {
            System.out.println("Rectangle3 is not a square :(");
        }         
        System.out.println();
    }  
}
