package debugrectangledriver;

/**
 *
 * @author Carol Spradling
 */
public class Rectangle {
    private double length;
    private double width;
    
    /** Creates a new instance of Rectangle */
    public Rectangle() 
    {
        length = 0.0;
        width = 0.0;
    }
    
    public Rectangle(double lengthIn, double widthIn)
    {
        length = lengthIn;
        width = widthIn;
    }
    
    public double getLength()
    {
        return length;
    }
    
    public double getWidth()
    {
        return width;
    }
    
    public double getArea()
    {
        return this.getWidth() * this.getLength();
    }
    
    public boolean isASquare()
    {
        return length == width;
    }
    
    public void setLength(double lengthIn)
    {
        length = lengthIn;
    }
    
    public void setWidth(double widthIn)
    {
        width = widthIn;
    }
    
    @Override
    public String toString()
    {
        return "Width: " + width + "\nLength: " + length;
    }
}
