public class BankAccount
{
  //################## instance variables ##################
  private double balance;

   //#################### constructor(s) ####################
   public BankAccount( double balance )
   {
       this.balance = balance;
   }
   //###################  other methods #####################
   public void deposit ( double amount )
   {
       this.balance = this.balance + amount;
   }
   
   public void withdraw ( double amount )
   {
       this.balance = this.balance - amount;
   }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + (int) (Double.doubleToLongBits(this.balance) ^ (Double.doubleToLongBits(this.balance) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final BankAccount other = (BankAccount) obj;
        if (Double.doubleToLongBits(this.balance) != Double.doubleToLongBits(other.balance)) {
            return false;
        }
        return true;
    }
   
   public double getBalance()
   {
       return balance;
   }
    
}  //======= end class BankAccount =======
