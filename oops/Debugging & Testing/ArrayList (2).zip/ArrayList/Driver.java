import java.util.ArrayList;

public class Driver
{
   public static void main( String[] args)
   {
      //Instantiates a BankAccount ArrayList
      ArrayList<BankAccount> accounts = new ArrayList<BankAccount>();
      
      //Example of how to use the ArrayList add() method to 
      //add elements to the array
      accounts.add( new BankAccount(1000) );
      accounts.add( new BankAccount(1015) );
      accounts.add( new BankAccount(2000) );

      //Example of how to get the entire ArrayList using the getBalance 
      //method from the BankAccount class by using a for loop
      //Note:  The ArrayList size() method is used to determine the  
      //size of the ArrayList
      System.out.println( "List of all bank account balances");
      for (int i = 0; i < accounts.size(); i++)
        System.out.print (accounts.get(i).getBalance() + "\n" );
      System.out.println();
      
      //Example of how to use an ArrayList get() method 
      //for one element in the array
      BankAccount anAccount = accounts.get(2);
      
      //Example of how to use ArrayList get() method and 
      //also call the getBalance() method from the BankAccount class
      //for one element of the ArrayList
      double myBalance = accounts.get(0).getBalance();
      System.out.println( "My balance is " + myBalance );
      System.out.println();
      
      //Example of how to determine how many elements are in the ArrayList
      int noOfAccounts = accounts.size();
      System.out.println( "Number of accounts " + noOfAccounts );
      System.out.println();
      
      //Example of how to use the ArrayList set() method
      //Note this sets the 3rd element in the ArrayList of type BankAccount
      //Note the ArrayList set() method overwrites the contents of the 
      //3rd element
      accounts.set(2, new BankAccount(3000) );
      
      //Example of how to use the ArrayList get() method and
      //and the getBalance() method of the BankAccount class
      //Note:  The entire ArrayList of type BankAccount will be printed
      //using the getBalance method from the BankAccount class 
      //and a for loop
      System.out.println( "List of all bank account balances");      
      for (int i = 0; i < accounts.size(); i++)
        System.out.print (accounts.get(i).getBalance()  + "\n" );
      System.out.println();
      
      //Example of how to use the ArrayList add() method to add 
      //another element to the accounts ArrayList
      accounts.add(2, new BankAccount(4000) );
            
      //Displays the balance for each element in the accounts ArrayList
      System.out.println( "List of all bank account balances");
      for (int i = 0; i < accounts.size(); i++)
        System.out.print (accounts.get(i).getBalance() + "\n" );   
      System.out.println();
      
      //Example of how to use the ArrayList remove() method
      accounts.remove(0);
      
      //Displays the balance for each element in the accounts ArrayList
      System.out.println( "List of all bank account balances");
      for (int i = 0; i < accounts.size(); i++)
        System.out.print (accounts.get(i).getBalance() + "\n" );   
      System.out.println();     
      
      //Example of how to use a enhanced for loop
      double totalAllBankBalances = 0;
      System.out.println( "List of all bank account balances");
      for (BankAccount oneBankAccount: accounts)
      {
          System.out.print(oneBankAccount.getBalance() + "\n");
          totalAllBankBalances = totalAllBankBalances 
          + oneBankAccount.getBalance();
      }
      System.out.println ( "Total balance for all bank accounts: " 
                            + totalAllBankBalances);
      System.out.println();
                            
      //Deposits 10000 to the BankAccount with an index of 2
      accounts.get(2).deposit(10000);
      
      //Withdraws 50 from the BankAccount with an index of 1
      accounts.get(1).withdraw(50);
      
      //Displays all the BankAccount objects in the ArrayList accounts
      //Uses an enhanced for loop
      System.out.println( "List of all bank account balances");
      for (BankAccount oneBankAccount: accounts)
      {
          System.out.print(oneBankAccount.getBalance() + "\n");
      }
   
   }  //===== end method main(String[]) =====   
}  //======= end class Driver =======
