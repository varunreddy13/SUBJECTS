
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author merry
 */
public class ComputePay01
{
	public static void main(String[] args) throws FileNotFoundException
	{
		Scanner in = new Scanner(new File("myData.txt"));
		String name = in.nextLine();
		int hours = in.nextInt();
		double rate = in.nextDouble();
		System.out.println(name + " worked " + hours + " hours at " +
			rate + " per hour and earned a total of $" + 
			hours * rate + ".");
		in.close();
	}
}
